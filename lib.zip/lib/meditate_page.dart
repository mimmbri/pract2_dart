import 'package:flutter/material.dart';

void main() {
  runApp(const MeditateApp());
}

class MeditateApp extends StatelessWidget {
  const MeditateApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: MeditatePage(),
    );
  }
}

class MeditatePage extends StatelessWidget {
  const MeditatePage({super.key});

  static const Color background = Color(0xFFF5F5F5);
  static const Color dark = Color(0xFF151515);
  static const Color grey = Color(0xFF8D8D8D);
  static const Color teal = Color(0xFF08A6AD);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: background,
      body: Center(
        child: FittedBox(
          fit: BoxFit.contain,
          child: SizedBox(
            width: 428,
            height: 926,
            child: Stack(
              children: [
                Container(width: 428, height: 926, color: Colors.white),

                Positioned(
                  top: 0,
                  left: 165,
                  child: Container(
                    width: 98,
                    height: 29,
                    decoration: const BoxDecoration(
                      color: Color(0xFFF1F1F1),
                      borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(17),
                        bottomRight: Radius.circular(17),
                      ),
                    ),
                  ),
                ),

                const Positioned(
                  left: 42,
                  top: 20,
                  child: Text(
                    '9:41',
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      height: 1,
                    ),
                  ),
                ),

                const Positioned(
                  left: 340,
                  top: 20,
                  child: CellularStatusIcon(),
                ),

                const Positioned(left: 367, top: 20, child: WifiStatusIcon()),

                const Positioned(
                  left: 397,
                  top: 20,
                  child: BatteryStatusIcon(),
                ),

                Positioned(
                  left: 26,
                  top: 62,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(15),
                    child: Image.asset(
                      'assets/images/meditate.png',
                      width: 373,
                      height: 252,
                      fit: BoxFit.cover,
                    ),
                  ),
                ),

                const Positioned(
                  left: 27,
                  top: 335,
                  child: Text(
                    'Peter Mach',
                    style: TextStyle(
                      color: grey,
                      fontSize: 12,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ),

                const Positioned(
                  left: 27,
                  top: 358,
                  child: Text(
                    'Mind Deep Relax',
                    style: TextStyle(
                      color: dark,
                      fontSize: 22,
                      fontWeight: FontWeight.w700,
                      height: 1,
                    ),
                  ),
                ),

                const Positioned(
                  left: 27,
                  top: 397,
                  right: 27,
                  child: Text(
                    'Join the Community as we prepare over 33 days\n'
                    'to relax and feel joy with the mind and happiness\n'
                    'session across the World.',
                    style: TextStyle(
                      color: Color(0xFF292929),
                      fontSize: 15,
                      fontWeight: FontWeight.w400,
                      height: 1.6,
                    ),
                  ),
                ),

                Positioned(
                  left: 27,
                  top: 493,
                  child: Container(
                    width: 373,
                    height: 54,
                    decoration: BoxDecoration(
                      color: teal,
                      borderRadius: BorderRadius.circular(28),
                    ),
                    child: const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        PlayIcon(size: 14, color: Colors.white),
                        SizedBox(width: 14),
                        Text(
                          'Play Next Session',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                const Positioned(
                  left: 26,
                  top: 590,
                  child: SessionItem(
                    color: Color(0xFF2F80ED),
                    title: 'Sweet Memories',
                    subtitle: 'December 29 Pre-Launch',
                  ),
                ),

                const Positioned(
                  left: 26,
                  top: 669,
                  child: SessionItem(
                    color: Color(0xFF08A6AD),
                    title: 'A Day Dream',
                    subtitle: 'December 29 Pre-Launch',
                  ),
                ),

                const Positioned(
                  left: 26,
                  top: 748,
                  child: SessionItem(
                    color: Color(0xFFFF922D),
                    title: 'Mind Explore',
                    subtitle: 'December 29 Pre-Launch',
                  ),
                ),

                Positioned(
                  left: 26,
                  top: 827,
                  child: Container(
                    width: 373,
                    height: 1,
                    color: const Color(0xFFF1F1F1),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class SessionItem extends StatelessWidget {
  final Color color;
  final String title;
  final String subtitle;

  const SessionItem({
    super.key,
    required this.color,
    required this.title,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 373,
      height: 63,
      child: Stack(
        children: [
          Container(
            width: 373,
            height: 63,
            decoration: const BoxDecoration(
              border: Border(
                bottom: BorderSide(color: Color(0xFFEAEAEA), width: 1),
              ),
            ),
          ),

          Positioned(
            left: 0,
            top: 0,
            child: Container(
              width: 46,
              height: 46,
              decoration: BoxDecoration(
                color: color,
                borderRadius: BorderRadius.circular(9),
              ),
              child: const Center(
                child: PlayIcon(size: 16, color: Colors.white),
              ),
            ),
          ),

          Positioned(
            left: 60,
            top: 1,
            child: Text(
              title,
              style: const TextStyle(
                color: Color(0xFF202020),
                fontSize: 17,
                fontWeight: FontWeight.w600,
                height: 1.1,
              ),
            ),
          ),

          Positioned(
            left: 60,
            top: 25,
            child: Text(
              subtitle,
              style: const TextStyle(
                color: Color(0xFF999999),
                fontSize: 11,
                fontWeight: FontWeight.w400,
                height: 1,
              ),
            ),
          ),

          const Positioned(right: 0, top: 21, child: MoreDots()),
        ],
      ),
    );
  }
}

class PlayIcon extends StatelessWidget {
  final double size;
  final Color color;

  const PlayIcon({super.key, required this.size, required this.color});

  @override
  Widget build(BuildContext context) {
    return CustomPaint(size: Size(size, size), painter: PlayIconPainter(color));
  }
}

class PlayIconPainter extends CustomPainter {
  final Color color;

  const PlayIconPainter(this.color);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    final path = Path()
      ..moveTo(size.width * 0.22, size.height * 0.12)
      ..lineTo(size.width * 0.22, size.height * 0.88)
      ..lineTo(size.width * 0.84, size.height * 0.50)
      ..close();

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return false;
  }
}

class MoreDots extends StatelessWidget {
  const MoreDots({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        _dot(),
        const SizedBox(width: 4),
        _dot(),
        const SizedBox(width: 4),
        _dot(),
      ],
    );
  }

  Widget _dot() {
    return Container(
      width: 6,
      height: 6,
      decoration: const BoxDecoration(
        color: Color(0xFFD7D7D7),
        shape: BoxShape.circle,
      ),
    );
  }
}

class CellularStatusIcon extends StatelessWidget {
  const CellularStatusIcon({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 18,
      height: 15,
      child: CustomPaint(painter: CellularPainter()),
    );
  }
}

class CellularPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final black = Paint()
      ..color = Colors.black
      ..style = PaintingStyle.fill;

    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(
          0,
          size.height * 0.6471,
          size.width * 0.1765,
          size.height * 0.3529,
        ),
        const Radius.circular(1.09744),
      ),
      black,
    );

    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(
          size.width * 0.2745,
          size.height * 0.4706,
          size.width * 0.1765,
          size.height * 0.5294,
        ),
        const Radius.circular(1.09744),
      ),
      black,
    );

    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(
          size.width * 0.5490,
          size.height * 0.2353,
          size.width * 0.1765,
          size.height * 0.7647,
        ),
        const Radius.circular(1.09744),
      ),
      black,
    );

    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(size.width * 0.8235, 0, size.width * 0.1765, size.height),
        const Radius.circular(1.09744),
      ),
      black,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return false;
  }
}

class WifiStatusIcon extends StatelessWidget {
  const WifiStatusIcon({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 18,
      height: 15,
      child: CustomPaint(painter: WifiPainter()),
    );
  }
}

class WifiPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF1C1C1E)
      ..style = PaintingStyle.fill;

    final outer = Path()
      ..moveTo(0, 3.2)
      ..quadraticBezierTo(size.width / 2, -3.0, size.width, 3.2)
      ..lineTo(size.width - 2.2, 5.6)
      ..quadraticBezierTo(size.width / 2, 0.2, 2.2, 5.6)
      ..close();

    final middle = Path()
      ..moveTo(3.4, 7.2)
      ..quadraticBezierTo(size.width / 2, 2.1, size.width - 3.4, 7.2)
      ..lineTo(size.width - 5.6, 9.6)
      ..quadraticBezierTo(size.width / 2, 5.0, 5.6, 9.6)
      ..close();

    final inner = Path()
      ..moveTo(6.8, 11.2)
      ..quadraticBezierTo(size.width / 2, 7.0, size.width - 6.8, 11.2)
      ..lineTo(size.width - 8.9, 13.4)
      ..quadraticBezierTo(size.width / 2, 9.6, 8.9, 13.4)
      ..close();

    canvas.drawPath(outer, paint);
    canvas.drawPath(middle, paint);
    canvas.drawPath(inner, paint);

    canvas.drawCircle(Offset(size.width / 2, 13.2), 1.5, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return false;
  }
}

class BatteryStatusIcon extends StatelessWidget {
  const BatteryStatusIcon({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 28,
      height: 14,
      child: CustomPaint(painter: BatteryPainter()),
    );
  }
}

class BatteryPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final outline = Paint()
      ..color = const Color(0xFF777777)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.4;

    final body = RRect.fromRectAndRadius(
      const Rect.fromLTWH(0, 1, 24, 12),
      const Radius.circular(3),
    );

    canvas.drawRRect(body, outline);

    final fill = Paint()
      ..color = const Color(0xFF1C1C1E)
      ..style = PaintingStyle.fill;

    canvas.drawRRect(
      RRect.fromRectAndRadius(
        const Rect.fromLTWH(2.5, 3.5, 18.5, 7),
        const Radius.circular(1.5),
      ),
      fill,
    );

    final cap = Paint()
      ..color = const Color(0xFF777777)
      ..style = PaintingStyle.fill;

    canvas.drawRRect(
      RRect.fromRectAndRadius(
        const Rect.fromLTWH(25, 5, 3, 4),
        const Radius.circular(1),
      ),
      cap,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return false;
  }
}
