import 'package:flutter/material.dart';

void main() {
  runApp(const MedinowApp());
}

class MedinowApp extends StatelessWidget {
  const MedinowApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: MedinowPage(),
    );
  }
}

class MedinowPage extends StatelessWidget {
  const MedinowPage({super.key});

  static const Color teal = Color(0xFF08A3A8);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F5),
      body: Center(
        child: FittedBox(
          fit: BoxFit.contain,
          child: SizedBox(
            width: 428,
            height: 926,
            child: Stack(
              children: [
                Positioned.fill(
                  child: Container(color: const Color(0xFFF5F5F5)),
                ),

                const Positioned(
                  left: 38,
                  top: 12,
                  child: Text(
                    'Welcome',
                    style: TextStyle(
                      fontSize: 16,
                      color: Color(0xFFB8B8B8),
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ),

                Positioned(
                  left: 38,
                  top: 41,
                  child: Container(
                    width: 371,
                    height: 804,
                    decoration: BoxDecoration(
                      color: teal,
                      borderRadius: BorderRadius.circular(5),
                    ),
                    child: Stack(
                      children: [
                        Positioned(
                          left: 113,
                          top: 0,
                          child: Container(
                            width: 146,
                            height: 30,
                            decoration: const BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.only(
                                bottomLeft: Radius.circular(15),
                                bottomRight: Radius.circular(15),
                              ),
                            ),
                          ),
                        ),

                        const Positioned(
                          left: 35,
                          top: 16,
                          child: Text(
                            '9:41',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),

                        const Positioned(
                          right: 91,
                          top: 19,
                          child: CellularIcon(),
                        ),

                        const Positioned(right: 62, top: 18, child: WifiIcon()),

                        const Positioned(
                          right: 32,
                          top: 18,
                          child: BatteryIcon(),
                        ),

                        const Positioned(
                          top: 136,
                          left: 0,
                          right: 0,
                          child: Text(
                            'medinow',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 38,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 0.3,
                            ),
                          ),
                        ),

                        const Positioned(
                          top: 184,
                          left: 0,
                          right: 0,
                          child: Text(
                            'Meditate With Us!',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 17,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),

                        Positioned(
                          left: 22,
                          top: 256,
                          child: Container(
                            width: 327,
                            height: 48,
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(28),
                            ),
                            child: const Text(
                              'Sign in with Apple',
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 16,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                        ),

                        Positioned(
                          left: 22,
                          top: 316,
                          child: Container(
                            width: 327,
                            height: 48,
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                              color: const Color(0xFFBFF3F5),
                              borderRadius: BorderRadius.circular(28),
                            ),
                            child: const Text(
                              'Continue with Email or Phone',
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 16,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                        ),

                        const Positioned(
                          top: 380,
                          left: 0,
                          right: 0,
                          child: Text(
                            'Continue With Google',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),

                        Positioned(
                          left: 7,
                          bottom: 38,
                          child: Image.asset(
                            'assets/images/meditation.png',
                            width: 357,
                            height: 290,
                            fit: BoxFit.contain,
                          ),
                        ),

                        Positioned(
                          left: 122,
                          bottom: 8,
                          child: Container(
                            width: 127,
                            height: 5,
                            decoration: BoxDecoration(
                              color: Colors.black,
                              borderRadius: BorderRadius.circular(5),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class CellularIcon extends StatelessWidget {
  const CellularIcon({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 18,
      height: 13,
      child: CustomPaint(painter: CellularPainter()),
    );
  }
}

class CellularPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.fill;

    canvas.drawRect(Rect.fromLTWH(0, 7, 3, 6), paint);

    canvas.drawRect(Rect.fromLTWH(5, 5, 3, 8), paint);

    canvas.drawRect(Rect.fromLTWH(10, 3, 3, 10), paint);

    canvas.drawRect(Rect.fromLTWH(15, 0, 3, 13), paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return false;
  }
}

class WifiIcon extends StatelessWidget {
  const WifiIcon({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 18,
      height: 14,
      child: CustomPaint(painter: WifiPainter()),
    );
  }
}

class WifiPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.8
      ..strokeCap = StrokeCap.round;

    final path1 = Path()
      ..moveTo(1, 3)
      ..quadraticBezierTo(9, -2, 17, 3);

    final path2 = Path()
      ..moveTo(4, 7)
      ..quadraticBezierTo(9, 3, 14, 7);

    canvas.drawPath(path1, paint);
    canvas.drawPath(path2, paint);

    final dot = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.fill;

    canvas.drawCircle(const Offset(9, 11), 1.5, dot);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return false;
  }
}

class BatteryIcon extends StatelessWidget {
  const BatteryIcon({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 23,
      height: 12,
      child: CustomPaint(painter: BatteryPainter()),
    );
  }
}

class BatteryPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.4;

    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(0, 1, 20, 10),
        const Radius.circular(2),
      ),
      paint,
    );

    final fill = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.fill;

    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(2, 3, 16, 6),
        const Radius.circular(1),
      ),
      fill,
    );

    canvas.drawRect(Rect.fromLTWH(20, 4, 3, 4), fill);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return false;
  }
}
