import 'package:flutter/material.dart';

void main() {
  runApp(const MyWeeklyTasksApp());
}

class MyWeeklyTasksApp extends StatelessWidget {
  const MyWeeklyTasksApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: MyWeeklyTasksPage(),
    );
  }
}

class MyWeeklyTasksPage extends StatelessWidget {
  const MyWeeklyTasksPage({super.key});

  static const Color bg = Color(0xFFF7F7F7);
  static const Color navy = Color(0xFF071A35);
  static const Color grey = Color(0xFF8B929A);
  static const Color line = Color(0xFFE2E2E2);
  static const Color blue = Color(0xFF587AF5);
  static const Color orange = Color(0xFFFFAA50);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg,
      body: Center(
        child: FittedBox(
          fit: BoxFit.contain,
          child: SizedBox(
            width: 428,
            height: 926,
            child: Stack(
              children: [
                Positioned.fill(child: Container(color: bg)),

                const Positioned(
                  left: 35.48,
                  top: 16.83,
                  child: SizedBox(
                    width: 44.26,
                    height: 20.12,
                    child: Text(
                      '10:01',
                      textAlign: TextAlign.right,
                      style: TextStyle(
                        fontFamily: 'SF Pro Text',
                        fontSize: 16.842,
                        fontWeight: FontWeight.w600,
                        height: 20 / 16.842,
                        letterSpacing: -0.084,
                        color: Colors.black,
                      ),
                    ),
                  ),
                ),

                const Positioned(
                  left: 331.79,
                  top: 20.85,
                  child: CellularIcon(),
                ),

                const Positioned(
                  left: 356.30,
                  top: 20.12,
                  child: SizedBox(
                    width: 18.31,
                    height: 13.17,
                    child: Icon(Icons.wifi, size: 18.31, color: Colors.black),
                  ),
                ),

                const Positioned(
                  left: 380.44,
                  top: 20.49,
                  child: BatteryIcon(),
                ),

                Positioned(
                  left: 30,
                  top: 68,
                  child: ClipOval(
                    child: Image.asset(
                      'assets/images/dan_smith.png',
                      width: 45,
                      height: 45,
                      fit: BoxFit.cover,
                    ),
                  ),
                ),

                const Positioned(
                  left: 83,
                  top: 69,
                  child: Text(
                    'Good Evening!',
                    style: TextStyle(
                      fontSize: 11,
                      color: grey,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ),

                const Positioned(
                  left: 83,
                  top: 89,
                  child: Text(
                    'Dan Smith',
                    style: TextStyle(
                      fontSize: 20,
                      color: navy,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),

                const Positioned(
                  left: 263,
                  top: 65,
                  child: HeaderButton(icon: Icons.search),
                ),

                Positioned(
                  left: 315,
                  top: 65,
                  child: Stack(
                    clipBehavior: Clip.none,
                    children: [
                      const HeaderButton(icon: Icons.notifications_none),
                      Positioned(
                        right: 5,
                        top: 6,
                        child: Container(
                          width: 8,
                          height: 8,
                          decoration: const BoxDecoration(
                            color: orange,
                            shape: BoxShape.circle,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                const Positioned(
                  left: 30,
                  top: 139,
                  child: Text(
                    'My Weekly Tasks',
                    style: TextStyle(
                      fontSize: 18,
                      color: navy,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),

                const Positioned(
                  left: 30,
                  top: 164,
                  child: Text(
                    '18 Tasks Pending',
                    style: TextStyle(fontSize: 10, color: grey),
                  ),
                ),

                const Positioned(left: 274, top: 141, child: FilterIcon()),

                Positioned(
                  left: 337,
                  top: 137,
                  child: Container(width: 1, height: 44, color: line),
                ),

                const Positioned(
                  left: 365,
                  top: 142,
                  child: Icon(Icons.add, size: 28, color: navy),
                ),

                const Positioned(
                  left: 20,
                  top: 204,
                  child: WeeklyCard(
                    category: 'UI/UX Design',
                    categoryColor: Color(0xFF875BF3),
                    categoryBg: Color(0xFFF0E8FF),
                    priority: 'High',
                    priorityColor: Color(0xFFFF7070),
                    priorityBg: Color(0xFFFFEDED),
                    title1: 'Create a',
                    title2: 'Landing Page',
                    date: 'Mon, 12 July 2022',
                    firstAvatar: 'assets/images/landing_avatar_1.png',
                    secondAvatar: 'assets/images/landing_avatar_2.png',
                    counter: '3+',
                  ),
                ),

                const Positioned(
                  left: 228,
                  top: 204,
                  child: WeeklyCard(
                    category: 'Development',
                    categoryColor: Color(0xFFFF9824),
                    categoryBg: Color(0xFFFFF0D9),
                    priority: 'Low',
                    priorityColor: Color(0xFF42C86B),
                    priorityBg: Color(0xFFE5F8EA),
                    title1: 'Develop a',
                    title2: 'Website',
                    date: 'Mon, 30 July 2022',
                    firstAvatar: 'assets/images/website_avatar_1.png',
                    secondAvatar: 'assets/images/website_avatar_2.png',
                    counter: '2+',
                  ),
                ),

                const Positioned(
                  left: 30,
                  top: 422,
                  child: Text(
                    'Today’s Tasks',
                    style: TextStyle(
                      fontSize: 18,
                      color: navy,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),

                const Positioned(
                  left: 30,
                  top: 448,
                  child: Text(
                    '18 Tasks Pending',
                    style: TextStyle(fontSize: 10, color: grey),
                  ),
                ),

                const Positioned(left: 274, top: 425, child: FilterIcon()),

                Positioned(
                  left: 337,
                  top: 420,
                  child: Container(width: 1, height: 44, color: line),
                ),

                const Positioned(
                  left: 365,
                  top: 426,
                  child: Icon(Icons.add, size: 28, color: navy),
                ),

                const Positioned(
                  left: 20,
                  top: 513,
                  child: TodayCard(
                    title: 'Design 2 App Screens',
                    subtitle: 'Crypto Wallet App',
                    date: 'Mon, 10 July 2022',
                    completed: true,
                    firstAvatar: 'assets/images/today_avatar_1.png',
                    secondAvatar: 'assets/images/today_avatar_2.png',
                  ),
                ),

                const Positioned(
                  left: 20,
                  top: 667,
                  child: TodayCard(
                    title: 'Design Homepage',
                    subtitle: 'Water Company Website',
                    date: '',
                    completed: false,
                    firstAvatar: '',
                    secondAvatar: '',
                  ),
                ),

                const Positioned(
                  left: 0,
                  right: 0,
                  bottom: 0,
                  child: BottomNavigation(),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class CellularIcon extends StatelessWidget {
  const CellularIcon({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 18.66,
      height: 12.44,
      child: CustomPaint(painter: CellularPainter()),
    );
  }
}

class CellularPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final black = Paint()
      ..color = Colors.black
      ..style = PaintingStyle.fill;

    final grey = Paint()
      ..color = const Color(0xFFC1C1C5)
      ..style = PaintingStyle.fill;

    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(
          0,
          size.height * 0.6471,
          size.width * 0.1765,
          size.height * 0.3529,
        ),
        const Radius.circular(1.09744),
      ),
      black,
    );

    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(
          size.width * 0.2745,
          size.height * 0.4706,
          size.width * 0.1765,
          size.height * 0.5294,
        ),
        const Radius.circular(1.09744),
      ),
      black,
    );

    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(
          size.width * 0.5490,
          size.height * 0.2353,
          size.width * 0.1765,
          size.height * 0.7647,
        ),
        const Radius.circular(1.09744),
      ),
      grey,
    );

    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(size.width * 0.8235, 0, size.width * 0.1765, size.height),
        const Radius.circular(1.09744),
      ),
      grey,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return false;
  }
}

class BatteryIcon extends StatelessWidget {
  const BatteryIcon({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 27.44,
      height: 13.17,
      child: CustomPaint(painter: BatteryPainter()),
    );
  }
}

class BatteryPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final borderPaint = Paint()
      ..color = const Color(0xFF919194)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.09744;

    final body = RRect.fromRectAndRadius(
      Rect.fromLTWH(0, 0, size.width * 0.9067, size.height),
      const Radius.circular(3.65812),
    );

    canvas.drawRRect(body, borderPaint);

    final fillPaint = Paint()
      ..color = Colors.black
      ..style = PaintingStyle.fill;

    final fill = RRect.fromRectAndRadius(
      Rect.fromLTWH(
        size.width * 0.08,
        size.height * 0.1667,
        size.width * 0.4533,
        size.height * 0.6666,
      ),
      const Radius.circular(1.82906),
    );

    canvas.drawRRect(fill, fillPaint);

    final contactPaint = Paint()
      ..color = const Color(0xFF79797B)
      ..style = PaintingStyle.fill;

    canvas.drawOval(
      Rect.fromLTWH(
        size.width * 0.8933,
        size.height * 0.3333,
        size.width * 0.1067,
        size.height * 0.3334,
      ),
      contactPaint,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return false;
  }
}

class HeaderButton extends StatelessWidget {
  final IconData icon;

  const HeaderButton({super.key, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 40,
      height: 40,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(color: const Color(0xFFE0E0E0), width: 1),
      ),
      child: Icon(icon, size: 23, color: const Color(0xFF071A35)),
    );
  }
}

class FilterIcon extends StatelessWidget {
  const FilterIcon({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 25,
      height: 25,
      child: CustomPaint(painter: FilterPainter()),
    );
  }
}

class FilterPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF071A35)
      ..strokeWidth = 1.7
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    canvas.drawLine(const Offset(2, 5), const Offset(23, 5), paint);

    canvas.drawLine(const Offset(2, 12), const Offset(23, 12), paint);

    canvas.drawLine(const Offset(2, 19), const Offset(23, 19), paint);

    final fill = Paint()
      ..color = const Color(0xFF071A35)
      ..style = PaintingStyle.fill;

    canvas.drawCircle(const Offset(8, 5), 2.5, fill);

    canvas.drawCircle(const Offset(17, 12), 2.5, fill);

    canvas.drawCircle(const Offset(10, 19), 2.5, fill);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return false;
  }
}

class WeeklyCard extends StatelessWidget {
  final String category;
  final Color categoryColor;
  final Color categoryBg;
  final String priority;
  final Color priorityColor;
  final Color priorityBg;
  final String title1;
  final String title2;
  final String date;
  final String firstAvatar;
  final String secondAvatar;
  final String counter;

  const WeeklyCard({
    super.key,
    required this.category,
    required this.categoryColor,
    required this.categoryBg,
    required this.priority,
    required this.priorityColor,
    required this.priorityBg,
    required this.title1,
    required this.title2,
    required this.date,
    required this.firstAvatar,
    required this.secondAvatar,
    required this.counter,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 190,
      height: 205,
      padding: const EdgeInsets.fromLTRB(14, 16, 12, 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(17),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                height: 28,
                padding: const EdgeInsets.symmetric(horizontal: 12),
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: categoryBg,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  category,
                  style: TextStyle(
                    fontSize: 9,
                    color: categoryColor,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Container(
                height: 28,
                padding: const EdgeInsets.symmetric(horizontal: 13),
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: priorityBg,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  priority,
                  style: TextStyle(
                    fontSize: 9,
                    color: priorityColor,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 28),
          Text(
            title1,
            style: const TextStyle(
              fontSize: 17,
              height: 1,
              color: Color(0xFF071A35),
              fontWeight: FontWeight.w700,
            ),
          ),
          Text(
            title2,
            style: const TextStyle(
              fontSize: 17,
              height: 1,
              color: Color(0xFF071A35),
              fontWeight: FontWeight.w700,
            ),
          ),
          const Spacer(),
          Row(
            children: [
              ImageAvatar(path: firstAvatar, size: 34),
              Transform.translate(
                offset: const Offset(-7, 0),
                child: ImageAvatar(path: secondAvatar, size: 34),
              ),
              Transform.translate(
                offset: const Offset(-4, 0),
                child: Container(
                  width: 32,
                  height: 32,
                  decoration: const BoxDecoration(
                    color: Color(0xFFFFAD51),
                    shape: BoxShape.circle,
                  ),
                  alignment: Alignment.center,
                  child: Text(
                    counter,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),
            ],
          ),
          const Spacer(),
          Row(
            children: [
              const Icon(
                Icons.calendar_today_outlined,
                size: 20,
                color: Colors.black,
              ),
              const SizedBox(width: 9),
              Expanded(
                child: Text(
                  date,
                  maxLines: 1,
                  overflow: TextOverflow.clip,
                  style: const TextStyle(
                    fontSize: 10,
                    color: Color(0xFF858B93),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class ImageAvatar extends StatelessWidget {
  final String path;
  final double size;

  const ImageAvatar({super.key, required this.path, required this.size});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: ClipOval(
        child: Image.asset(path, width: size, height: size, fit: BoxFit.cover),
      ),
    );
  }
}

class TodayCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final String date;
  final bool completed;
  final String firstAvatar;
  final String secondAvatar;

  const TodayCard({
    super.key,
    required this.title,
    required this.subtitle,
    required this.date,
    required this.completed,
    required this.firstAvatar,
    required this.secondAvatar,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 388,
      height: 136,
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(17),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            height: 48,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(top: 15),
                    child: Text(
                      title,
                      maxLines: 1,
                      overflow: TextOverflow.clip,
                      style: TextStyle(
                        fontSize: 16,
                        color: const Color(0xFF071A35),
                        fontWeight: FontWeight.w700,
                        decoration: completed
                            ? TextDecoration.lineThrough
                            : TextDecoration.none,
                        decorationThickness: 2,
                      ),
                    ),
                  ),
                ),
                if (completed)
                  Container(
                    width: 58,
                    height: 58,
                    decoration: const BoxDecoration(
                      color: Color(0xFF587AF5),
                      shape: BoxShape.circle,
                    ),
                    child: const Center(
                      child: SizedBox(
                        width: 32,
                        height: 32,
                        child: CustomPaint(painter: CheckPainter()),
                      ),
                    ),
                  ),
              ],
            ),
          ),
          Text(
            subtitle,
            style: const TextStyle(fontSize: 10, color: Color(0xFF858B93)),
          ),
          const SizedBox(height: 9),
          Container(height: 1, color: const Color(0xFFE1E1E1)),
          const SizedBox(height: 8),
          if (date.isNotEmpty)
            SizedBox(
              height: 30,
              child: Row(
                children: [
                  const Icon(
                    Icons.calendar_today_outlined,
                    size: 21,
                    color: Colors.black,
                  ),
                  const SizedBox(width: 10),
                  Text(
                    date,
                    style: const TextStyle(
                      fontSize: 10,
                      color: Color(0xFF858B93),
                    ),
                  ),
                  const Spacer(),
                  ImageAvatar(path: firstAvatar, size: 32),
                  Transform.translate(
                    offset: const Offset(-7, 0),
                    child: ImageAvatar(path: secondAvatar, size: 32),
                  ),
                  Transform.translate(
                    offset: const Offset(-4, 0),
                    child: Container(
                      width: 32,
                      height: 32,
                      decoration: const BoxDecoration(
                        color: Color(0xFFFFAD51),
                        shape: BoxShape.circle,
                      ),
                      alignment: Alignment.center,
                      child: const Text(
                        '1+',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

class CheckPainter extends CustomPainter {
  const CheckPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white
      ..strokeWidth = 2.2
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    final path = Path()
      ..moveTo(size.width * 0.16, size.height * 0.52)
      ..lineTo(size.width * 0.42, size.height * 0.76)
      ..lineTo(size.width * 0.87, size.height * 0.23);

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return false;
  }
}

class BottomNavigation extends StatelessWidget {
  const BottomNavigation({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 93,
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: Color(0xFFE2E2E2), width: 1)),
      ),
      child: Stack(
        children: [
          const BottomItem(
            left: 26.8,
            title: 'Home',
            painter: HomePainter(),
            active: true,
          ),

          const BottomItem(
            left: 106.8,
            title: 'Projects',
            painter: ProjectsPainter(),
          ),

          const BottomItem(
            left: 186.3,
            title: 'Calendar',
            painter: CalendarPainter(),
          ),

          const BottomItem(
            left: 270.3,
            title: 'Messages',
            painter: MessagesPainter(),
            notification: true,
          ),

          const BottomItem(
            left: 349.0,
            title: 'Members',
            painter: MembersPainter(),
          ),
        ],
      ),
    );
  }
}

class BottomItem extends StatelessWidget {
  final double left;
  final String title;
  final CustomPainter painter;
  final bool active;
  final bool notification;

  const BottomItem({
    super.key,
    required this.left,
    required this.title,
    required this.painter,
    this.active = false,
    this.notification = false,
  });

  @override
  Widget build(BuildContext context) {
    final color = active ? const Color(0xFF557AFF) : const Color(0xFFAAAAAA);

    return Positioned(
      left: left,
      top: 22.5,
      child: SizedBox(
        width: 52,
        child: Column(
          children: [
            SizedBox(
              width: 26.4,
              height: 26.4,
              child: Stack(
                clipBehavior: Clip.none,
                children: [
                  Positioned.fill(child: CustomPaint(painter: painter)),

                  if (notification)
                    Positioned(
                      right: -5,
                      top: -4,
                      child: Container(
                        width: 20,
                        height: 20,
                        decoration: const BoxDecoration(
                          color: Color(0xFFFFA84D),
                          shape: BoxShape.circle,
                        ),
                      ),
                    ),
                ],
              ),
            ),

            const SizedBox(height: 8),

            SizedBox(
              width: 80,
              child: Text(
                title,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 10,
                  height: 1,
                  color: color,
                  fontWeight: FontWeight.w400,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class HomePainter extends CustomPainter {
  const HomePainter();

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF557AFF)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.65
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    final path = Path();

    path.moveTo(size.width * 0.1875, size.height * 0.4583);

    path.lineTo(size.width * 0.50, size.height * 0.125);

    path.lineTo(size.width * 0.8125, size.height * 0.4583);

    path.lineTo(size.width * 0.8125, size.height * 0.75);

    path.quadraticBezierTo(
      size.width * 0.8125,
      size.height * 0.9167,
      size.width * 0.6458,
      size.height * 0.9167,
    );

    path.lineTo(size.width * 0.3542, size.height * 0.9167);

    path.quadraticBezierTo(
      size.width * 0.1875,
      size.height * 0.9167,
      size.width * 0.1875,
      size.height * 0.75,
    );

    path.close();

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return false;
  }
}

class ProjectsPainter extends CustomPainter {
  const ProjectsPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.black
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.65
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    final path = Path();

    path.moveTo(size.width * 0.1875, size.height * 0.2917);

    path.quadraticBezierTo(
      size.width * 0.1875,
      size.height * 0.125,
      size.width * 0.3542,
      size.height * 0.125,
    );

    path.lineTo(size.width * 0.6458, size.height * 0.125);

    path.quadraticBezierTo(
      size.width * 0.8125,
      size.height * 0.125,
      size.width * 0.8125,
      size.height * 0.2917,
    );

    path.lineTo(size.width * 0.8125, size.height * 0.75);

    path.quadraticBezierTo(
      size.width * 0.8125,
      size.height * 0.875,
      size.width * 0.6875,
      size.height * 0.875,
    );

    path.lineTo(size.width * 0.3125, size.height * 0.875);

    path.quadraticBezierTo(
      size.width * 0.1875,
      size.height * 0.875,
      size.width * 0.1875,
      size.height * 0.75,
    );

    path.close();

    canvas.drawPath(path, paint);

    canvas.drawLine(
      Offset(size.width * 0.3542, size.height * 0.125),
      Offset(size.width * 0.3542, size.height * 0.0417),
      paint,
    );

    canvas.drawLine(
      Offset(size.width * 0.6458, size.height * 0.125),
      Offset(size.width * 0.6458, size.height * 0.0417),
      paint,
    );

    canvas.drawLine(
      Offset(size.width * 0.3333, size.height * 0.4583),
      Offset(size.width * 0.6667, size.height * 0.4583),
      paint,
    );

    canvas.drawLine(
      Offset(size.width * 0.3333, size.height * 0.6667),
      Offset(size.width * 0.6667, size.height * 0.6667),
      paint,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return false;
  }
}

class CalendarPainter extends CustomPainter {
  const CalendarPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.black
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.65
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    final rect = RRect.fromRectAndRadius(
      Rect.fromLTWH(
        size.width * 0.1458,
        size.height * 0.1042,
        size.width * 0.7084,
        size.height * 0.7916,
      ),
      const Radius.circular(5),
    );

    canvas.drawRRect(rect, paint);

    canvas.drawLine(
      Offset(size.width * 0.1458, size.height * 0.375),
      Offset(size.width * 0.8542, size.height * 0.375),
      paint,
    );

    canvas.drawLine(
      Offset(size.width * 0.3542, size.height * 0.0208),
      Offset(size.width * 0.3542, size.height * 0.2708),
      paint,
    );

    canvas.drawLine(
      Offset(size.width * 0.6458, size.height * 0.0208),
      Offset(size.width * 0.6458, size.height * 0.2708),
      paint,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return false;
  }
}

class MessagesPainter extends CustomPainter {
  const MessagesPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.black
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.65
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    final path = Path();

    path.moveTo(size.width * 0.2917, size.height * 0.125);

    path.lineTo(size.width * 0.7083, size.height * 0.125);

    path.quadraticBezierTo(
      size.width * 0.875,
      size.height * 0.125,
      size.width * 0.875,
      size.height * 0.2917,
    );

    path.lineTo(size.width * 0.875, size.height * 0.5833);

    path.quadraticBezierTo(
      size.width * 0.875,
      size.height * 0.75,
      size.width * 0.7083,
      size.height * 0.75,
    );

    path.lineTo(size.width * 0.4583, size.height * 0.75);

    path.lineTo(size.width * 0.2083, size.height * 0.875);

    path.lineTo(size.width * 0.2917, size.height * 0.75);

    path.lineTo(size.width * 0.2917, size.height * 0.75);

    path.quadraticBezierTo(
      size.width * 0.125,
      size.height * 0.75,
      size.width * 0.125,
      size.height * 0.5833,
    );

    path.lineTo(size.width * 0.125, size.height * 0.2917);

    path.quadraticBezierTo(
      size.width * 0.125,
      size.height * 0.125,
      size.width * 0.2917,
      size.height * 0.125,
    );

    path.close();

    canvas.drawPath(path, paint);

    canvas.drawLine(
      Offset(size.width * 0.2917, size.height * 0.4167),
      Offset(size.width * 0.7083, size.height * 0.4167),
      paint,
    );

    canvas.drawLine(
      Offset(size.width * 0.2917, size.height * 0.5833),
      Offset(size.width * 0.5833, size.height * 0.5833),
      paint,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return false;
  }
}

class MembersPainter extends CustomPainter {
  const MembersPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.black
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.65
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    canvas.drawCircle(
      Offset(size.width * 0.3542, size.height * 0.3333),
      size.width * 0.125,
      paint,
    );

    canvas.drawCircle(
      Offset(size.width * 0.6667, size.height * 0.3333),
      size.width * 0.125,
      paint,
    );

    final leftBody = Path();

    leftBody.moveTo(size.width * 0.1042, size.height * 0.875);

    leftBody.quadraticBezierTo(
      size.width * 0.1042,
      size.height * 0.6458,
      size.width * 0.3542,
      size.height * 0.6458,
    );

    leftBody.quadraticBezierTo(
      size.width * 0.6042,
      size.height * 0.6458,
      size.width * 0.6042,
      size.height * 0.875,
    );

    canvas.drawPath(leftBody, paint);

    final rightBody = Path();

    rightBody.moveTo(size.width * 0.3958, size.height * 0.875);

    rightBody.quadraticBezierTo(
      size.width * 0.3958,
      size.height * 0.6458,
      size.width * 0.6667,
      size.height * 0.6458,
    );

    rightBody.quadraticBezierTo(
      size.width * 0.8958,
      size.height * 0.6458,
      size.width * 0.8958,
      size.height * 0.875,
    );

    canvas.drawPath(rightBody, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return false;
  }
}
