import 'package:flutter/material.dart';

void main() {
  runApp(
    const MaterialApp(debugShowCheckedModeBanner: false, home: PodcastPage()),
  );
}

class PodcastPage extends StatelessWidget {
  const PodcastPage({super.key});

  static const Color cream = Color(0xFFFAF6F5);
  static const Color blue = Color(0xFF01C3FF);
  static const Color orange = Color(0xFFFE7A15);
  static const Color purple = Color(0xFF403285);
  static const Color darkPurple = Color(0xFF1D0F5A);
  static const Color yellow = Color(0xFFF8D910);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF3F1F0),
      body: Center(
        child: FittedBox(
          fit: BoxFit.contain,
          child: Container(
            width: 466.15,
            height: 1009.36,
            decoration: BoxDecoration(
              color: cream,
              border: Border.all(color: Colors.white, width: 14.04),
              borderRadius: BorderRadius.circular(49.72),
              boxShadow: const [
                BoxShadow(
                  color: Color(0x08000000),
                  blurRadius: 28,
                  offset: Offset(0, 5),
                ),
              ],
            ),
            child: Stack(
              children: [
                Positioned(
                  left: -47.24,
                  top: -12.43,
                  child: SizedBox(
                    width: 513.38,
                    height: 410.21,
                    child: Image.asset(
                      'assets/images/atlantis.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                ),

                Positioned(
                  left: 0,
                  top: 0,
                  child: Container(
                    width: 466.15,
                    height: 397.78,
                    decoration: const BoxDecoration(color: blue),
                  ),
                ),

                Positioned(
                  left: -47.24,
                  top: -12.43,
                  child: SizedBox(
                    width: 513.38,
                    height: 410.21,
                    child: Image.asset(
                      'assets/images/atlantis.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                ),

                Positioned(
                  left: -6.22,
                  top: 336.87,
                  child: CustomPaint(
                    size: const Size(477.33, 63.4),
                    painter: WhiteWavePainter(),
                  ),
                ),

                Positioned(
                  left: 176.51,
                  top: 295.85,
                  child: Container(
                    width: 103.17,
                    height: 101.93,
                    decoration: BoxDecoration(
                      color: orange,
                      shape: BoxShape.circle,
                      border: Border.all(color: cream, width: 9.94),
                    ),
                    child: const Center(
                      child: Icon(
                        Icons.play_arrow,
                        color: Colors.white,
                        size: 48,
                      ),
                    ),
                  ),
                ),

                Positioned(
                  left: 35.45,
                  top: 42.47,
                  child: Container(
                    width: 48.48,
                    height: 48.48,
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.7),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      Icons.arrow_back,
                      color: Colors.black,
                      size: 29,
                    ),
                  ),
                ),

                const Positioned(
                  left: 67.12,
                  top: 407.72,
                  child: SizedBox(
                    width: 333,
                    height: 42,
                    child: Text(
                      'Secrets of Atlantis',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontFamily: 'Montserrat',
                        fontSize: 34.8,
                        height: 1.2,
                        fontWeight: FontWeight.w700,
                        color: Color(0xFF111111),
                      ),
                    ),
                  ),
                ),

                Positioned(
                  left: 164.45,
                  top: 458.36,
                  child: Container(
                    width: 138,
                    height: 38,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      border: Border.all(color: orange, width: 1),
                      borderRadius: BorderRadius.circular(7.46),
                    ),
                    child: const Text(
                      'Follow',
                      style: TextStyle(
                        fontFamily: 'Montserrat',
                        fontSize: 17,
                        fontWeight: FontWeight.w600,
                        color: orange,
                      ),
                    ),
                  ),
                ),

                Positioned(
                  left: 24.86,
                  top: 524.57,
                  child: Container(
                    width: 416.42,
                    height: 270.99,
                    decoration: BoxDecoration(
                      color: purple,
                      borderRadius: BorderRadius.circular(39.78),
                    ),
                    child: Stack(
                      children: [
                        Positioned(
                          left: 19.89,
                          top: 29.84,
                          child: ClipOval(
                            child: Image.asset(
                              'assets/images/codin.png',
                              width: 59.67,
                              height: 59.67,
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),

                        const Positioned(
                          left: 89.5,
                          top: 29.84,
                          child: Text(
                            'Codin',
                            style: TextStyle(
                              fontFamily: 'Montserrat',
                              fontSize: 16.16,
                              fontWeight: FontWeight.w600,
                              color: Colors.white,
                            ),
                          ),
                        ),

                        Positioned(
                          left: 89.5,
                          top: 54.7,
                          child: Container(
                            width: 53.45,
                            height: 21.13,
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                              color: const Color(0xFF262044),
                              borderRadius: BorderRadius.circular(4.97),
                            ),
                            child: const Text(
                              'Host',
                              style: TextStyle(
                                fontFamily: 'Montserrat',
                                fontSize: 14.9,
                                fontWeight: FontWeight.w500,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ),

                        const Positioned(
                          left: 159.11,
                          top: 27.35,
                          child: SizedBox(
                            width: 237.42,
                            height: 84,
                            child: Text(
                              'The Secrets of Atlantis podcast is designed for all fantasy enthusiasts, everything from debunking underwat... see more',
                              style: TextStyle(
                                fontFamily: 'Montserrat',
                                fontSize: 13.67,
                                height: 1.5,
                                fontWeight: FontWeight.w500,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ),

                        Positioned(
                          left: 19.89,
                          top: 135.49,
                          child: Container(
                            width: 89.5,
                            height: 29.83,
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                              color: const Color(0xFF271D5A),
                              borderRadius: BorderRadius.circular(7.46),
                            ),
                            child: const Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.star, color: Colors.white, size: 18),
                                SizedBox(width: 4),
                                Text(
                                  '4.8',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 16,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                                SizedBox(width: 6),
                                Text(
                                  '(10)',
                                  style: TextStyle(
                                    color: Colors.white54,
                                    fontSize: 16,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),

                        Positioned(
                          left: 129.28,
                          top: 135.49,
                          child: Container(
                            width: 75.83,
                            height: 29.83,
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                              color: const Color(0xFF271D5A),
                              borderRadius: BorderRadius.circular(7.46),
                            ),
                            child: const Text(
                              'Fantasy',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                        ),

                        const Positioned(
                          right: 20,
                          top: 136,
                          child: Icon(
                            Icons.notifications_none,
                            color: Colors.white,
                            size: 30,
                          ),
                        ),

                        Positioned(
                          left: 0,
                          right: 0,
                          bottom: 0,
                          child: Container(
                            height: 88.26,
                            decoration: const BoxDecoration(
                              color: darkPurple,
                              borderRadius: BorderRadius.only(
                                bottomLeft: Radius.circular(39.78),
                                bottomRight: Radius.circular(39.78),
                              ),
                            ),
                            child: Stack(
                              children: [
                                const Positioned(
                                  left: 20,
                                  top: 20,
                                  child: AvatarRow(),
                                ),

                                Positioned(
                                  right: 18,
                                  top: 29,
                                  child: Row(
                                    children: const [
                                      Icon(
                                        Icons.wifi_tethering,
                                        color: Color(0xFFF24E1E),
                                        size: 23,
                                      ),
                                      SizedBox(width: 5),
                                      Text(
                                        'Live',
                                        style: TextStyle(
                                          color: Color(0xFFF24E1E),
                                          fontSize: 19.9,
                                          fontWeight: FontWeight.w700,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                Positioned(
                  left: 51,
                  top: 829,
                  child: Container(
                    width: 367,
                    height: 136,
                    decoration: BoxDecoration(
                      color: yellow,
                      borderRadius: BorderRadius.circular(53.45),
                    ),
                    child: Stack(
                      children: [
                        Positioned(
                          left: 12,
                          top: 10,
                          child: SizedBox(
                            width: 150,
                            height: 115,
                            child: CustomPaint(painter: InvitePainter()),
                          ),
                        ),

                        const Positioned(
                          left: 174,
                          top: 42,
                          child: SizedBox(
                            width: 139,
                            child: Text(
                              'Invite your\nfriends to join',
                              style: TextStyle(
                                fontFamily: 'Montserrat',
                                fontSize: 17.4,
                                height: 1.5,
                                fontWeight: FontWeight.w700,
                                color: Colors.black,
                              ),
                            ),
                          ),
                        ),

                        const Positioned(
                          right: 18,
                          top: 48,
                          child: Icon(
                            Icons.share,
                            color: Color(0xFF3B3838),
                            size: 24,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                Positioned(
                  left: 170,
                  bottom: 9,
                  child: Container(
                    width: 127,
                    height: 5,
                    decoration: BoxDecoration(
                      color: Colors.black,
                      borderRadius: BorderRadius.circular(5),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class WhiteWavePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFFFAF6F5)
      ..style = PaintingStyle.fill;

    final path = Path();

    path.moveTo(0, size.height * 0.35);

    path.quadraticBezierTo(
      size.width * 0.25,
      0,
      size.width * 0.52,
      size.height * 0.20,
    );

    path.quadraticBezierTo(
      size.width * 0.76,
      size.height * 0.43,
      size.width,
      size.height * 0.20,
    );

    path.lineTo(size.width, size.height);

    path.lineTo(0, size.height);

    path.close();

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return false;
  }
}

class AvatarRow extends StatelessWidget {
  const AvatarRow({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 162,
      height: 40,
      child: Stack(
        children: [
          avatar('assets/images/avatar1.png', 0),
          avatar('assets/images/avatar2.png', 30),
          avatar('assets/images/avatar3.png', 61),
          avatar('assets/images/avatar4.png', 91),

          Positioned(
            left: 122,
            top: 0,
            child: Container(
              width: 40,
              height: 40,
              alignment: Alignment.center,
              decoration: const BoxDecoration(
                color: Color(0xFFFE7A15),
                shape: BoxShape.circle,
              ),
              child: const Text(
                '+10',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 13.67,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget avatar(String path, double left) {
    return Positioned(
      left: left,
      top: 0,
      child: Container(
        width: 40,
        height: 40,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(color: Colors.black, width: 1),
        ),
        child: ClipOval(
          child: Image.asset(path, width: 40, height: 40, fit: BoxFit.cover),
        ),
      ),
    );
  }
}

class InvitePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    const double pi = 3.141592653589793;

    final cream = Paint()
      ..color = const Color(0xFFFAF6F5)
      ..style = PaintingStyle.fill;

    final orange = Paint()
      ..color = const Color(0xFFFE7A15)
      ..style = PaintingStyle.fill;

    final blue = Paint()
      ..color = const Color(0xFF32ABFF)
      ..style = PaintingStyle.fill;

    final white = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.fill;

    final black = Paint()
      ..color = const Color(0xFF050505)
      ..style = PaintingStyle.fill;

    canvas.save();

    canvas.translate(48, 76);
    canvas.rotate(-7 * pi / 180);
    canvas.translate(-48, -76);

    canvas.drawCircle(const Offset(48, 76), 48, cream);

    canvas.drawCircle(const Offset(48, 76), 41.5, orange);

    final orangeFace = Paint()
      ..color = const Color(0xFF050505)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3.6
      ..strokeCap = StrokeCap.round;

    canvas.drawArc(
      const Rect.fromLTWH(15, 57, 19, 11),
      0.15,
      2.45,
      false,
      orangeFace,
    );

    canvas.drawArc(
      const Rect.fromLTWH(39, 54, 19, 11),
      0.15,
      2.45,
      false,
      orangeFace,
    );

    canvas.drawArc(
      const Rect.fromLTWH(34, 68, 20, 11),
      0.10,
      2.35,
      false,
      orangeFace,
    );

    canvas.restore();

    canvas.save();

    const double pivotX = 105;
    const double pivotY = 63;

    canvas.translate(pivotX, pivotY);
    canvas.rotate(26 * pi / 180);
    canvas.translate(-pivotX, -pivotY);

    final blueCard = RRect.fromRectAndRadius(
      const Rect.fromLTWH(67, 25, 80, 80),
      const Radius.circular(18),
    );

    canvas.drawRRect(blueCard.inflate(5.8), white);

    canvas.drawRRect(blueCard, blue);

    canvas.drawCircle(const Offset(91, 48), 12.5, white);

    canvas.drawCircle(const Offset(115, 52), 12.5, white);

    canvas.drawCircle(const Offset(92, 49), 3.4, black);

    canvas.drawCircle(const Offset(116, 53), 3.4, black);

    final mouth = Path()
      ..moveTo(94, 70)
      ..lineTo(115, 75)
      ..lineTo(113, 83)
      ..lineTo(92, 78)
      ..close();

    canvas.drawPath(mouth, black);

    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return false;
  }
}
